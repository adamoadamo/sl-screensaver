Hello there. 

Thank you for choosing this disparate cast of characters to populate your desktop or laptop screen. You will see that they appear and disappear from view at random. You may wish for some to stay longer and others to leave as soon as they arrive. You may guess at the relationships between certain pairings without ever really knowing the full scope of their stories. Isn’t that just how things go? People drift in and out of your life, and they all look like anthropomorphic objects; or they are animals - literal animals; or they wear one ridiculously oversized piece of clothing and nothing else. 

They seem happy, but it’s hard to say for sure. You never really know how people are feeling in public, unless they are running around screaming and crying. And even then, your best educated guess could be completely wrong. You could stop the screamer, grasp them firmly by their shoulders, look them straight in the eyebrows, and ask if everything’s okay, and they might say through a teary, snot-‘stached smile, “Actually, I’m the happiest I’ve ever been. That’s the problem.” 

So thank you again. I hope you find this to be fun and friendly. If you’d like to work on something together, you can reach me at suerynn [at] gmail [dot] com. 

This project was made in loving collaboration with Adam Taylor O’Reilly.

Okay here are your long awaited install instructions:


Screensaver for macOS 12.0+

Step 1: Install the Screensaver
1	Double-click the .saver file in this folder.
2	A prompt will appear—click Install.

Step 2: Activate Your Screensaver
1	Open System Settings (or System Preferences on older Macs).
2	Click on Desktop & Screen Saver.
3	Go to the Screen Saver tab.
4	Scroll down to the Other section—you'll find your new screensaver there!
5	Select it to make it your active screensaver.
